MDS5120 Group G14 Report v4 — 28 November 2026

31-page English PDF and editable Word.
Reorganized around requirements, ER relationships, relational mapping, normalization, implementation and evaluation. Eight BR identifiers connect business obligations to constraints, transactions and evidence.
Current design: 15 tables, 24 foreign keys, 127 physical columns. All 24 ER relationships match inspected SQL foreign keys. Shared id and created_at columns are described once in Appendix A.

This is a report revision. Application code and measured experiments are reused from the tested v3 source snapshot. team-tests.txt records 48 passed cases; earlier tests.xml contains 40 and is retained as historical evidence.
The live parallel and attachment experiments are separate captures. Costs use demonstration rates, not provider invoices.

For source reproduction use AgentDesk-source-v3.zip and evidence/source-v3-sha256.json. Configure your own environment; credentials and runtime databases are excluded. scripts/schema_evidence_v4.py runs from the repository root and creates/removes an isolated schema in the configured local test database. Other evidence collectors retain their documented layout requirements.

No GitHub push or course submission was performed for this revision.
