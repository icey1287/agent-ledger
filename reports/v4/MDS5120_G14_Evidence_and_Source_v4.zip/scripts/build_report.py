from pathlib import Path
import json, math, hashlib, xml.etree.ElementTree as ET
from collections import Counter
from PIL import Image, ImageDraw, ImageFont
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
O=Path(__file__).resolve().parents[1];E=O/'evidence';F=O/'figures'
live=json.loads((E/'live-demo.json').read_text()); check=json.loads((E/'live-independent-check.json').read_text()); bench=json.loads((E/'index-benchmark.json').read_text()); env=json.loads((E/'environment.json').read_text())
FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
def font(n):return ImageFont.truetype(FONT,n)
def diagram():
 im=Image.new('RGB',(1600,1080),'white');d=ImageDraw.Draw(im)
 boxes={'users':(20,40),'sessions':(410,40),'plans':(1180,40),'subscriptions':(800,210),'conversations':(20,360),'tasks':(410,530),'model_prices':(1180,530),'models':(1180,360),'materials':(20,740),'task_tool_grants':(410,900),'agent_runs':(800,740),'model_calls':(1180,900),'tool_calls':(800,900)}
 edges=[('users','sessions'),('users','conversations'),('users','subscriptions'),('plans','subscriptions'),('subscriptions','tasks'),('conversations','tasks'),('model_prices','tasks'),('models','model_prices'),('tasks','materials'),('tasks','task_tool_grants'),('tasks','agent_runs'),('agent_runs','model_calls'),('agent_runs','tool_calls'),('task_tool_grants','tool_calls')]
 for a,b in edges:
  x,y=boxes[a];u,v=boxes[b];start=(x+150,y+45);end=(u+150,v+45)
  dx,dy=end[0]-start[0],end[1]-start[1];length=math.hypot(dx,dy); ux,uy=dx/length,dy/length
  edge=min(150/max(abs(ux),1e-9),45/max(abs(uy),1e-9)); s=(start[0]+ux*(edge+3),start[1]+uy*(edge+3));t=(end[0]-ux*(edge+6),end[1]-uy*(edge+6))
  d.line([s,t],fill='#8a9299',width=3)
  d.polygon([t,(t[0]-ux*14-uy*7,t[1]-uy*14+ux*7),(t[0]-ux*14+uy*7,t[1]-uy*14-ux*7)],fill='#8a9299')
 for name,(x,y) in boxes.items():
  d.rounded_rectangle((x,y,x+300,y+90),radius=10,fill='#edf2f5',outline='#34495e',width=2)
  d.text((x+150,y+45),name,font=font(25),fill='#17232c',anchor='mm')
 d.text((25,1040),'Arrow: parent key to referencing rows (one to many). Supplementary links are listed below.',font=font(23),fill='#333333')
 im.save(F/'relationships.png')
def chart():
 im=Image.new('RGB',(1500,650),'white');d=ImageDraw.Draw(im);labels=['No timeline index','Single column','Composite']
 vals=[bench['conditions'][k]['median_ms'] for k in bench['conditions']]
 for j,(label,v) in enumerate(zip(labels,vals)):
  y=100+j*150;d.text((20,y+25),label,font=font(32),fill='#222')
  length=(math.log10(v)+3)/4*870
  d.rectangle((390,y,390+length,y+70),fill=['#8b9299','#59758a','#245574'][j]);d.text((410+length,y+18),f'{v:.3f} ms',font=font(29),fill='#222')
 for val in [.001,.01,.1,1,10]:
  x=390+(math.log10(val)+3)/4*870;d.line((x,545,x,555),fill='#333',width=2);d.text((x,565),str(val),font=font(24),fill='#333',anchor='mt')
 d.line((390,550,1260,550),fill='#333',width=2);d.text((825,615),'Median execution time in milliseconds (log scale)',font=font(27),fill='#333',anchor='mm')
 im.save(F/'benchmark.png')
diagram();chart()
doc=Document();s=doc.sections[0];s.page_width=Inches(8.27);s.page_height=Inches(11.69);s.top_margin=Inches(.75);s.bottom_margin=Inches(.7);s.left_margin=Inches(.82);s.right_margin=Inches(.82)
styles=doc.styles
for name in ['Normal','Body Text']:
 styles[name].font.name='Times New Roman';styles[name].font.size=Pt(11);styles[name].paragraph_format.space_after=Pt(7);styles[name].paragraph_format.line_spacing=1.12
for name,size in [('Title',23),('Heading 1',16),('Heading 2',12),('Heading 3',11)]:
 st=styles[name];st.font.name='Times New Roman';st.font.size=Pt(size);st.font.color.rgb=RGBColor(0,0,0);st.paragraph_format.space_before=Pt(11);st.paragraph_format.space_after=Pt(7)
for st in styles:
 for el in list(st.element.iter()):
  if el.tag==qn('w:pBdr'): el.getparent().remove(el)
  if el.tag==qn('w:rFonts'):
   for attr in list(el.attrib):
    if 'theme' in attr.lower():del el.attrib[attr]
styles['Caption'].font.name='Times New Roman';styles['Caption'].font.size=Pt(9);styles['Caption'].font.color.rgb=RGBColor.from_string('333333')
header=s.header.paragraphs[0];header.text='MDS5120  |  GROUP G14                                          AGENT DESK';header.style='Caption'
footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=footer.add_run();fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),'PAGE');r._r.addnext(fld)
doc.core_properties.title='AI Agent Subscription and Task Billing Database System';doc.core_properties.author='MDS5120 Group G14';doc.core_properties.subject='Database design, implementation and empirical validation'
def p(t):return doc.add_paragraph(t)
def h(t):doc.add_heading(t,2)
def page(t):doc.add_page_break();doc.add_heading(t,1)
def table(headers,rows,widths=None):
 t=doc.add_table(rows=1, cols=len(headers));t.autofit=False
 if widths:
  for col,w in zip(t.columns,widths):col.width=Inches(w)
 for c,txt in zip(t.rows[0].cells,headers):c.text=str(txt)
 for row in rows:
  for c,txt in zip(t.add_row().cells,row):c.text=str(txt)
 for i,row in enumerate(t.rows):
  trPr=row._tr.get_or_add_trPr();no=OxmlElement('w:cantSplit');trPr.append(no)
  if i==0:
   repeat=OxmlElement('w:tblHeader');trPr.append(repeat)
  for j,c in enumerate(row.cells):
   if widths:c.width=Inches(widths[j])
   tcPr=c._tc.get_or_add_tcPr();shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E9EDF0' if i==0 else 'FFFFFF');tcPr.append(shade)
   for para in c.paragraphs:
    para.paragraph_format.space_after=Pt(4);para.paragraph_format.space_before=Pt(4);para.paragraph_format.line_spacing=1.02
    for r in para.runs:r.font.size=Pt(9.5);r.bold=(i==0)
 doc.add_paragraph().paragraph_format.space_after=Pt(0)
 return t
def fig(name,caption,width=6.5):doc.add_picture(str(F/name),width=Inches(width));doc.add_paragraph(caption,'Caption')
def code(t):
 q=p(t);q.paragraph_format.space_after=Pt(8)
 for r in q.runs:r.font.name='Courier New';r.font.size=Pt(8.5)
# Cover
p('THE CHINESE UNIVERSITY OF HONG KONG SHENZHEN').alignment=WD_ALIGN_PARAGRAPH.CENTER
q=doc.add_paragraph('AI Agent Subscription and Task Billing Database System','Title');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
q=p('Agent Desk\nMDS5120 Database Systems Group Project Report\nGroup G14 • 28 November 2026');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
table(['Member','Student ID'],[['Changze Li','226040366'],['Peng Si','226040350'],['Haodong He','226040345'],['Yiming Zhang','226040349'],['Qijie Weng','226040416'],['Zhikang An','226040336']],[3.7,2.8])
h('Abstract')
p('Agent Desk implements a relational database for subscription eligibility and auditable AI task usage. A conversation contains independently budgeted tasks; each task fixes a model price version, an enrollment record and tool permissions. Thirteen tables connect accounts, subscriptions, uploaded material, agent execution and individual model calls. The design treats missing provider usage as an unresolved value rather than a zero charge, and uses row locks, unique constraints and explicit transactions to preserve business invariants under concurrent requests.')
p('Validation combines three distinct forms of evidence: 40 automated tests against an isolated PostgreSQL database with simulated provider responses; a real DeepSeek attachment workflow with seven recorded calls; and a controlled index experiment over 200,000 generated tasks. All tests passed. The live workflow read both PDF and TXT material, completed coordinator, summary and review roles, and produced an independently verified ledger total of USD 0.0068438 at the configured demonstration rates. The composite conversation timeline index reduced median server execution time from 4.208 ms without a timeline index to 0.009 ms in a warm-cache experiment. These findings support the prototype’s tested integrity and traceability, while leaving production payments, distributed execution and broader workload evaluation outside the demonstrated scope.')
p('Keywords: relational design; subscription eligibility; transaction isolation; usage accounting; PostgreSQL; auditability.')
# 2
page('1 Context and Requirements')
p('An AI application can generate a useful answer while leaving its operator unable to explain who was entitled to request it, which model price applied, or whether a timeout produced a charge. These are persistent business-data questions. Agent Desk therefore treats a model response as one outcome of a task whose eligibility, permissions, execution and usage must remain traceable. The application provides a concrete workload for the database rather than making model training the project objective.')
p('The business actors are a registered user, an administrator and an external model provider. Users enroll in a demonstration plan, maintain conversations, upload text-bearing documents and inspect their own execution histories. Administrators maintain the model catalog and append price versions, then reconcile unresolved usage using evidence. The provider supplies responses and usage metadata but does not participate in a PostgreSQL transaction.')
table(['Requirement','Database consequence','Observable acceptance condition'],[
['Subscription eligibility','plans, subscriptions and task enrollment link','Both task entry points reject users without a currently valid enrollment.'],
['Historical pricing','A task references one model_prices row','Changing the current price cannot reprice an accepted task.'],
['Reliable accounting','One model_calls row per attempt; nullable unresolved cost','Missing usage remains NULL and prevents further dispatch.'],
['User isolation','Ownership links plus authenticated predicates','A user cannot read another user’s task or material.'],
['Controlled tools','Task-scoped grants and tool invocation history','Expired or revoked permission prevents later reads.'],
['Concurrent requests','User, conversation, task and call row locks','Repeated enrollment and reconciliation do not duplicate effects.'],
['Durable history','Foreign keys and additive migrations','Legacy records survive upgrades and interrupted tasks remain visible.']],[1.35,2.0,3.15])
h('1.1 Scope and acceptance boundaries')
p('The two seeded plans are a seven-day trial with a zero display price and a thirty-day standard demonstration plan displaying USD 9.90. Enrollment is an access-control event. It neither collects payment nor credits a provider wallet. Per-call usage costs remain a separate ledger. Re-enrollment, cancellation and expiry are implemented; automatic renewal and periodic token quotas are not.')
p('The course brief calls for business context, conceptual ER/EER design, relational design, implementation and discussion [1]. The following sections address those stages explicitly. The index comparison is additional empirical analysis, not a substitute for logical correctness. No claim of production readiness or guaranteed spending limits follows from the demonstration.')
# 3
page('2 Conceptual Data Model')
p('The model separates a continuing conversation from its individual task executions. Each task belongs to a user, selects a price version and may reference an enrollment. It owns material, grants and agent runs. An agent run can parent another run; the application restricts this hierarchy to a coordinator and the two supported specialist roles. Model calls and tool calls are separate events because a local material read does not itself incur model usage.')
fig('relationships.png','Figure 1. Core parent-to-child relationships in the 13-table schema. Each arrow indicates one parent to zero or more referencing rows. See the text for optional and supplementary links.',6.5)
p('All entities have a primary identifier. A session, conversation and subscription each require exactly one user. A subscription requires one plan; a task’s price is mandatory. New application-created tasks require a valid subscription, while the database permits a NULL enrollment link for legacy tasks. The conversation link is also nullable for legacy compatibility. A root run has no parent, and a delegation tool call need not reference a material grant.')
p('Supplementary relationships omitted from the diagram to preserve readability are users → tasks, users → model_calls.reconciled_by and the agent_runs self-reference. The task–subscription relationship is enforced through the pair (subscription_id, user_id), ensuring that an enrollment cannot be borrowed from a different account. The grant associated with a tool invocation records the authorization basis, while the invocation output records the observed outcome.')
# 4
page('3 Relational Mapping')
p('Each entity becomes a relation with a VARCHAR(36) primary key. One-to-many relationships place a foreign key on the child relation; the agent hierarchy uses a nullable self-referencing key. UTC-aware TIMESTAMPTZ values preserve time instants, even when a client displays them in a local timezone. NUMERIC stores rates and costs without binary floating-point approximation. Appendix A lists the physical columns extracted from the fresh SQL schema.')
table(['Relation','Selected keys and relationships','Principal content'],[
['users','PK id; UNIQUE username','Password hash and user/admin role'],['sessions','PK id; FK user_id; UNIQUE token_hash','Session expiry and CSRF token'],['models','PK id; UNIQUE name','Provider model identifier and enabled flag'],['model_prices','PK id; FK model_id; UNIQUE(model_id, version)','Currency and three versioned rates'],['plans','PK id; UNIQUE code','Duration, display price and enabled flag'],['subscriptions','PK id; FK user_id, plan_id','Enrollment interval and plan snapshot'],['conversations','PK id; FK user_id','Title and activity timestamps'],['tasks','PK id; FK user_id, conversation_id, price_id','Instruction, result, budget, status and subscription link'],['materials','PK id; FK task_id','Name, type and extracted document text'],['task_tool_grants','PK id; FK task_id; UNIQUE(task_id, tool)','Expiry and revocation timestamps'],['agent_runs','PK id; FK task_id, parent_id','Role, instruction, status and output'],['model_calls','PK id; FK run_id, reconciled_by','Tokens, cost, raw usage and reconciliation evidence'],['tool_calls','PK id; FK run_id, grant_id','Tool, arguments, result and outcome']],[1.25,2.8,2.45])
h('3.1 Why the call is the accounting unit')
p('A task may contain several agents, and an agent may invoke the model several times. Recording only a task total would hide the attempt that timed out, the tokens consumed after cancellation, and the basis of a correction. The call relation is therefore the authoritative unit of usage; task totals are aggregates. The schema stores no independently editable total invoice for the same event, avoiding a second balance that could drift from the detailed ledger.')
p('Tool arguments and raw provider usage use JSON because their fields vary with the operation or provider. Stable business attributes such as status, tokens and cost remain typed columns. This combination keeps forensic detail without forcing ordinary billing queries to parse provider-specific JSON. The application does not allow the JSON payload to override ownership, price or confirmed usage fields.')
#5
page('4 Normalization and Integrity')
h('4.1 Functional dependencies and deliberate duplication')
p('The model catalog separates model identity from price history. In model_prices, (model_id, version) determines the rates, currency and pricing note, and is a candidate key alongside id. In task_tool_grants, (task_id, tool) determines the grant record. These alternate keys prevent duplicate business facts even though the application uses surrogate identifiers for joins. Splitting users from sessions and conversations from tasks avoids repeating credentials and conversation metadata on every event.')
p('A blanket claim that every relation is in third normal form would be too strong. tasks repeats user_id even though a non-null conversation_id normally identifies an owner. This supports direct ownership checks and legacy tasks, but creates a consistency obligation. The present database has separate foreign keys for the conversation and user rather than a composite ownership foreign key. Normal API writes enforce the relationship; direct SQL writes could still create an inconsistent pair. A composite conversation-owner constraint is a clear next hardening step.')
p('Subscription plan name, display price and currency are enrollment-time snapshots. They intentionally describe a historical agreement rather than the current plan row. Stored model_calls.cost is similarly a derived, auditable result. The calculation is centralized in the billing module and independently checked in experiments, but no database trigger recalculates arbitrary direct SQL updates. Price immutability is enforced by application write paths, not by an UPDATE-denying database trigger.')
table(['Invariant','Enforcement layer','Reason or limit'],[
['Unknown usage implies NULL cost','Cross-field CHECK','A numeric zero would falsely assert a known outcome.'],['Known usage requires all token counts and cost','CHECK plus NOT NULL predicates inside the condition','Prevents partially populated confirmed records.'],['Nonnegative counts; cached ≤ input','CHECK','Cached tokens are a subset, not extra input.'],['One stored active enrollment per user','Partial unique index','Elapsed time is checked separately at request time.'],['Task and enrollment have same owner','Composite foreign key','Blocks cross-account subscription references.'],['No duplicate price version or grant','UNIQUE constraints','Identity remains stable under competing inserts.'],['Valid period and cancellation timestamp','CHECK','Rejects reversed intervals and contradictory cancellation fields.'],['State vocabulary','CHECK','Rejects unknown strings; transition order remains application logic.']],[1.85,1.75,2.9])
p('PostgreSQL constraints reject invalid row states independently of the interface [3]. Cross-row transition policies still require transactions. A CHECK that validates an allowed state name does not prove that a completed task reached that state through a valid execution path.')
#6
page('5 Subscription Lifecycle')
p('Subscriptions make the project topic operational: access to a new AI task depends on a persisted enrollment, and every new task retains that enrollment identifier. The eligibility predicate is status = active AND starts_at ≤ server time < ends_at. The exclusive upper endpoint avoids ambiguity at expiry. The server captures the time after obtaining the user lock, so a request waiting behind another transaction is evaluated at its actual admission point.')
table(['Event','Behavior','Historical effect'],[
['Enroll without a current plan','Lock user; validate enabled plan; create snapshot','New enrollment row with fixed start and end times'],['Repeat the same active plan','Return the existing enrollment','No second row and no extension of expiry'],['Request a different plan while active','Reject with HTTP 409','Existing enrollment remains unchanged'],['Cancel before expiry','Set cancelled status and timestamp','New tasks blocked; prior accepted tasks remain valid'],['Read after expiry','Derive effective expired status from time','No scheduler is required to block new tasks'],['Enroll after expiry','Mark old active row expired; insert new row','Previous enrollment and task links remain queryable']],[1.8,2.5,2.2])
h('5.1 Synchronizing admission and cancellation')
p('Enrollment, cancellation and task admission lock the same user row. Task admission then locks the conversation. If cancellation commits first, a later admission sees the cancelled state and is rejected. If admission commits first, the task is already accepted and may finish even if cancellation follows. This policy defines a precise boundary rather than attempting to retract a model request already sent to an external service.')
p('The partial unique index on user_id WHERE status = active prevents two stored active rows, including direct inserts. It does not encode the passage of time: a row can retain stored status active after its end time until another operation archives it. The public response derives effective expiry, and admission checks both timestamps. Counting stored active rows alone would therefore overstate currently eligible users.')
h('5.2 Separating entitlement from money movement')
p('The plan display price is a snapshot for demonstration and analysis. It is not recognized revenue. A subscription may authorize several tasks, each with its own model price version and currency. Joining a subscription to calls repeats the plan row; summing that repeated display price would multiply a nominal amount by the number of calls. The subscription query therefore keeps plan price as a grouping attribute and sums only call costs within each usage currency.')
p('Tests cover absent subscriptions at both message endpoints, repeated enrollment, expiry and renewal, disabled plans, user isolation, CSRF protection, concurrent enrollment, invalid direct writes, legacy NULL links and cancellation of an already accepted task. These tests establish the implemented entitlement behavior without implying payment processing.')
#7
page('6 Transactions and Concurrency')
p('The system uses short database transactions around decisions and durable events. A transaction does not remain open while waiting for the model provider. This avoids holding database locks during a potentially slow network operation, but creates a deliberate uncertainty window between recording an attempt and confirming its response. Recovery preserves that uncertainty rather than silently retrying.')
table(['Operation','Lock order and transaction boundary','Property tested'],[
['Accept a task','User → conversation; insert task, materials and grants together','Concurrent sends in one conversation cannot both start'],['Enroll or cancel','User first; enrollment update and insert commit together','Concurrent same-plan enrollment yields one record'],['Claim pending work','Task row; pending → running','Execution is claimed conditionally'],['Start provider request','Create in_flight call and commit before HTTP','An interrupted external attempt remains discoverable'],['Record response','Persist response, usage and cost together','No partially confirmed accounting state'],['Change tool permission or read','Task → grant','Authorization decision and revocation have a defined order'],['Reconcile usage','Task → model call','Competing or repeated confirmations cannot double-charge']],[1.4,3.1,2.0])
h('6.1 Idempotent reconciliation')
p('An administrator may confirm usage only after obtaining reliable evidence. The original task price is used even if a newer price exists. A repeat request returns the confirmed record rather than overwriting it. A still-running call cannot be reconciled. The concurrency regression submits competing reconciliations and verifies that a single confirmed result survives. PostgreSQL row locks provide the serialization point; the application rechecks state after locking [4].')
h('6.2 Cancellation and unresolved work')
p('Cancellation prevents subsequent dispatch but does not erase a call already sent. Its eventual usage is recorded while the task remains cancelled. Similarly, a conversation cannot accept another turn while an earlier cancelled task still has an in-flight call. This avoids overlapping histories whose costs and responses are not yet settled. Different conversations can execute concurrently, although each individual task dispatches serially.')
p('On restart, lingering in-flight calls become usage_unknown and related tasks become awaiting_usage. Other unfinished tasks become interrupted. The application does not resume or replay them automatically. The tests confirm that restart recovery changes database state without making a provider request. This design favors an honest unresolved ledger over an apparently successful task that might have been billed twice.')
p('The deployment is a single Python application process. These controls do not demonstrate a distributed job queue, crash-proof exactly-once external execution or safe multi-worker recovery. Those properties would require an explicit worker ownership and delivery protocol, not merely additional database constraints.')
#8
page('7 Usage Accounting and Budget Semantics')
p('Let I be input tokens, C the cached subset of input, and O output tokens. Let ri, rc and ro be the ordinary-input, cached-input and output rates per million tokens. The stored call cost uses exact Decimal arithmetic and a task-fixed price version:')
q=p('cost = ((I − C) × ri + C × rc + O × ro) / 1,000,000');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
p('The demonstration rates are USD 0.50, 0.10 and 2.00 respectively. For I = 1,000, C = 200 and O = 100, the cost is (800 × 0.50 + 200 × 0.10 + 100 × 2.00) / 1,000,000 = USD 0.00062. Adding cached tokens to the full input count would overcharge. Reasoning tokens already included in provider output counts are not added a second time.')
table(['Observed outcome','Stored interpretation','Execution consequence'],[
['Complete valid usage','Known counts and numeric cost','May continue if other conditions permit'],['Explicit rejection with known zero usage','Known counts of zero and zero cost','Failure remains distinguishable from uncertainty'],['Missing or malformed usage','Unknown usage and NULL cost','Stop and await evidence'],['Cached usage but no applicable cache rate','Cost cannot be established reliably','Do not substitute an estimated rate'],['Timeout or ambiguous server failure','Attempt may have consumed tokens','No automatic retry; manual reconciliation'],['Confirmed usage after cancellation','Retain actual recorded cost','Do not turn cancelled work into successful completion']],[2.0,2.25,2.25])
h('7.1 A soft threshold is not a spending guarantee')
p('Before dispatch, the executor compares known accumulated cost with the task budget. A subsequent call can itself exceed that budget because its eventual usage is not known in advance. If that call supplies a complete final response, the task can complete with an over-budget total; if more calls are needed, execution stops. The interface explains this behavior. Hard reservation or a provider-enforced output ceiling is not implemented, so the report does not present the budget as a maximum invoice.')
h('7.2 Aggregation must preserve uncertainty')
p('SUM ignores NULL values, which is useful for the known subtotal but dangerous when displayed as a final charge. Every relevant aggregate therefore includes an unresolved-call count. A subtotal of zero with one unknown call means no confirmed amount yet, not a free task. A zero with zero unknown calls may be a genuinely known zero. Queries must also distinguish no calls from a completed zero-cost call when the business question requires that difference.')
p('Monetary values cross the API as decimal strings. The database stores NUMERIC(24,12), while plan display prices use NUMERIC(12,2). Neither the local call ledger nor the plan display price is a supplier invoice. The live demonstration below validates the configured calculation, not the provider’s actual account debit.')
#9
page('8 Implementation and Operational Boundaries')
p('The application is a modular monolith: Vue 3 and TypeScript render the user interface; FastAPI handles authentication and business requests; SQLAlchemy maps relational entities; PostgreSQL persists the state; and an adapter sends OpenAI-compatible HTTP requests to the configured provider. The experiment used DeepSeek deepseek-flash. Default repository configuration and older sample rows mention OpenRouter models, so they must not be mistaken for the provider used in the live test.')
table(['Component','Implemented responsibility'],[
['auth.py and session tables','Argon2id passwords, hashed session tokens, user/admin distinction and CSRF checks'],['subscriptions.py','Plan seeding, enrollment snapshots, cancellation and admission eligibility'],['workspaces.py and materials.py','Conversation ownership, atomic task creation and TXT/PDF text extraction'],['execution.py / provider.py','Fixed coordinator/summary/review roles, tool dispatch and external request recording'],['billing.py and admin.py','Usage validation, exact cost calculation and evidence-based reconciliation'],['schema.py and SQL migrations','Missing tables, legacy conversation upgrade, constraints and indexes'],['Vue views and API client','Conversation history, subscription controls, execution detail and administration']],[2.3,4.2])
h('8.1 Material and authorization boundaries')
p('Attachments are stored as extracted text with their source names and types. The implementation handles text-bearing PDF and TXT; it does not perform OCR. The tools accept material identifiers, not arbitrary local filesystem paths. A task can access earlier attachments in the same conversation if the current task has the relevant grant. A new conversation does not inherit them. Revocation prevents subsequent reads but cannot remove text already sent to the model or included in a previous reply.')
h('8.2 Schema evolution and deployment')
p('Initialization creates missing mapped tables, applies subscription additions, upgrades legacy conversations and adds named constraints and indexes. Migration stages use transactions and advisory locking where implemented. The entire initialization pipeline is not one all-or-nothing transaction. A backup is therefore required before upgrades, and an invalid historical row may stop a later stage after an earlier stage has already completed. Tests verify row preservation and rejection of dirty historical accounting data.')
p('The evaluated deployment binds the frontend and API to localhost and uses a separate PostgreSQL instance on port 55432. Public deployment would need HTTPS, secure cookie configuration and operational access controls. The current recovery routine supports one application process. No claim is made about throughput under multiple API workers, adversarial traffic or a distributed worker fleet.')
p('This report describes the tested working tree, including local subscription additions beyond base commit 0d66e63112df90c2fc48ed0453b80910968b8cf0. The source snapshot and per-file hashes accompany the evidence; the base Git commit alone does not reproduce those additions.')
#10
page('9 Validation Design and Automated Results')
p('Three evidence classes answer different questions. Automated tests exercise deterministic failures and races with a real PostgreSQL database but replace the external provider at the HTTP transport boundary. A live model demonstration validates integration and persisted events for one input. A generated-data benchmark examines a specific query plan. None of these alone measures general model accuracy, production reliability or realistic demand.')
root=ET.parse(E/'tests.xml').getroot();cases=list(root.iter('testcase'));counts=Counter(c.attrib.get('classname','').split('.')[-1] for c in cases)
table(['Test module','Cases passed','Coverage represented'],[[k,str(v),{'test_database':'Constraint negatives, fresh/upgrade paths, rollback, price-preserving reconciliation and sample SQL.','test_workflows':'Concurrent sending, ownership isolation, missing usage and restart behavior.','test_subscriptions':'Eligibility, enrollment lifecycle, concurrent idempotency, owner links and cancellation.'}.get(k,'Parameterized integration tests.')] for k,v in counts.items()],[1.65,.85,4.0])
p('The recorded run passed all 40 cases in 2.76 seconds, with no skipped tests. Each test creates a random schema in the dedicated agent_ledger_test database and removes that schema afterward. The provider fixture uses a test-only endpoint and simulated responses, so this run incurs no model charges. A Starlette TestClient deprecation warning was emitted; it does not change the pass result but should be addressed during dependency maintenance.')
h('9.1 What the negative tests establish')
p('A positive example only shows that one valid row can be stored. The suite also tries inconsistent known/unknown usage states, negative or inconsistent counts, invalid subscription fields and cross-user enrollment references. Rejection demonstrates that core integrity rules hold below the UI. Fresh SQL creation and application initialization are compared for named checks and query indexes, and repeated migration is exercised. This comparison is narrower than a proof that all defaults or every schema attribute are identical.')
h('9.2 Concurrent and historical cases')
p('The suite tests simultaneous message admission, competing enrollment and competing reconciliation. These are targeted regression schedules, not a stress test with arbitrary interleavings. Historical tests retain original rows during upgrades, preserve the original price when confirming usage and prevent repeated correction from overwriting a confirmed result. The sample-data assertions check the documented known, over-budget and unresolved accounting cases.')
p('Frontend type checking and the production build also passed. The live browser workflow verified attachment submission and visible execution details. Browser validation is a demonstrated path, not a complete accessibility or cross-browser test matrix. The test log, JUnit XML, build log and environment metadata are retained as separate evidence files.')
#11
page('10 Live Attachment Demonstration')
p('On 28 November 2026, a subscribed user submitted two files through the local browser interface: a text-bearing PDF and a TXT file containing the same fictional canteen note. The prompt requested both files be read without double-counting, one summary delegation and one review delegation. The task budget was USD 0.03 at demonstration rates. Only this fictional material was used for the model experiment.')
table(['Question','Independent expected result','Observed final response'],[
['Meal-volume change','(120 − 100) / 100 = 20%','20% increase'],['Two-day revenue','(100 + 120) × CNY 15 = CNY 3,300','CNY 3,300'],['Two-day profit','3,300 − 900 − 1,080 = CNY 1,320','CNY 1,320'],['Semester profit claim','Not justified by two daily observations','Rejected; missing evidence explained']],[1.5,2.8,2.2])
fig('live-result.jpg','Figure 2. Unaltered browser capture of the live workflow. The interface is Chinese; the requested model response is English. Numerical and ledger results are reproduced in readable tables in this report.',4.9)
p('The reviewer also identified a missing caveat in the summary: the source figures were fictional. The final response included that caveat. This single result demonstrates the requested data path and a useful review action; it is not a statistical comparison showing that multiple roles improve accuracy over one role.')
#12
page('11 Independent Review of the Live Ledger')
p('The task completed in approximately 11.68 seconds, from 15:08:45.779 to 15:08:57.455 Asia/Shanghai. The database contains three completed agent runs, seven successful model calls, four completed material reads and two completed delegation tools. Both material identifiers appear in the successful read events. The task has a non-null subscription link. These persisted records provide stronger evidence than the model’s own claim that it read a file.')
table(['Call','Role','Input','Output','Cached','Cost USD'],[[str(i),r['role'],str(r['input_tokens']),str(r['output_tokens']),str(r['cached_tokens']),f"{float(r['cost']):.7f}"] for i,r in enumerate(live['calls'],1)]+[['Total','',str(check['input_tokens']),str(check['output_tokens']),str(check['cached_tokens']),'0.0068438']],[.45,1.25,.85,.85,.85,1.25])
p('The seven costs were recalculated independently from each call’s token counts and the task-linked price row, using Decimal arithmetic. All seven matched exactly at the stored precision. Input and output sum to 14,501 tokens; the 7,808 cached tokens are already contained in the 12,690 input tokens and must not be added again. The known total is USD 0.0068438 and the unresolved-call count is zero.')
h('11.1 Traceability from entitlement to usage')
p('A separate SQL join follows subscriptions → tasks → agent_runs → model_calls and groups by the subscription and usage currency. Restricted to this demonstration task, it returns one task, seven calls and the same known cost. This establishes that the new subscription function participates in the recorded business workflow rather than existing only as an isolated settings page.')
h('11.2 Interpreting the agent trace')
p('The coordinator made four model calls, the summary role one, and the review role two. The coordinator read each attachment and the review role read each again. The summary role used the information supplied through its delegated context. The final prose says the duplicate information was “read once”; the tool trace shows four actual read operations. The defensible interpretation is that the figures were counted once in the arithmetic, not that the system performed exactly one physical read.')
p('Repeated access is not necessarily an error: a reviewer may inspect the original independently. It does create additional context and usage. A future controlled comparison should test whether that extra work improves error detection across a diverse set of documents. The present report makes no efficiency or accuracy claim from a single example. Captured costs use configured demonstration rates and must not be interpreted as the provider’s actual invoice.')
#13
page('12 Business SQL Results')
p('The repository sample-data script was loaded into a fresh disposable schema with the current DDL. These are deterministic business fixtures, separate from the live user database. Queries aggregate calls through their agent run and task, retain uncertainty counts and preserve historical price references. The SQL text and resulting JSON are included in the evidence package.')
table(['Task fixture','Status','Budget USD','Known subtotal USD','Unknown calls'],[['t-alice-1','completed','0.0100','0.00228','0'],['t-alice-2','stopped_budget','0.0005','0.00140','0'],['t-alice-3','awaiting_usage','0.0100','0','1'],['t-bob-1','cancelled','0.0100','0','0']],[1.15,1.45,1.0,1.8,1.1])
h('12.1 The same subtotal can mean different things')
p('The unresolved Alice task and the cancelled Bob task both have a displayed known subtotal of zero. Their semantics differ: Alice has one unknown call with NULL cost, while Bob has a confirmed zero-usage failed call. The task status and unknown count must therefore accompany the aggregate. Presenting only SUM(cost) would conceal the unresolved obligation. The query uses COUNT(call.id) for event counts so that an outer-join placeholder is not counted as an actual call.')
code("SELECT t.id, COALESCE(SUM(c.cost), 0) AS known_cost,\n       COUNT(c.id) FILTER\n         (WHERE c.usage_status = 'unknown') AS unknown_calls\nFROM tasks t\nLEFT JOIN agent_runs r ON r.task_id = t.id\nLEFT JOIN model_calls c ON c.run_id = r.id\nGROUP BY t.id;")
h('12.2 Historical and arithmetic checks')
p('The four nonzero confirmed fixture calls recalculate to USD 0.00062, 0.00100, 0.00066 and 0.00140. The unknown call remains NULL under the same expression; the known-zero call recalculates to zero. The first three calls sum to USD 0.00228. The second Alice task exceeds its USD 0.0005 soft threshold by USD 0.0009, illustrating why a stop policy and an invoice cap are different concepts.')
p('Two Alice tasks and the Bob task still reference model price version 1; the later unresolved Alice task references version 2. This result verifies the fixture’s historical links rather than simulating a market price change. Tool outcome aggregation returns four completed and three denied events. These values are seeded test cases, not observed success rates for real users.')
h('12.3 Avoiding joins that multiply costs')
p('Agent runs can have both model calls and tool calls. Joining both child tables in one unaggregated query would multiply rows when a run has several of each. Billing queries follow only the model-call branch, or should pre-aggregate independent branches before combining them. Similarly, currencies are grouped separately, and subscription display prices are not summed over task-call joins. These choices make the query grain explicit.')
#14
page('13 Controlled Index Experiment')
p('The tested query retrieves the first 50 tasks of one conversation ordered by created_at and id. A deterministic workload adds 200,000 tasks spread evenly across 1,000 generated conversations, or 200 tasks per conversation. Four pre-existing fixture tasks remain, producing 200,004 rows in the physical tasks table. The query selects one generated conversation. All conditions use the same data and remaining schema indexes.')
code("SELECT id, created_at FROM tasks\nWHERE conversation_id = 'bench-c-501'\nORDER BY created_at, id LIMIT 50;")
p('Three conditions remove both relevant timeline indexes, retain only conversation_id, or retain only the composite (conversation_id, created_at, id) index. Each condition receives ANALYZE, one warmup and twenty EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) measurements. The planner is not forced to use an index. Result-row hashes match in all conditions. The experiment runs in fixed condition order with one connection on an Apple M5 with 16 GiB memory and PostgreSQL 17.')
fig('benchmark.png','Figure 3. Median PostgreSQL execution time, 20 measurements per condition. The horizontal axis is logarithmic; these are warm-cache server timings, not browser latency.',6.4)
table(['Index condition','Median ms','Range ms','Returned rows'],[[{'no_timeline_index':'None of the two','single_column':'conversation_id','composite':'conversation_id, created_at, id'}[k],f"{v['median_ms']:.3f}",f"{v['min_ms']:.3f}–{v['max_ms']:.3f}",str(v['row_count'])] for k,v in bench['conditions'].items()],[2.6,1.1,1.6,1.2])
p('The composite index median is about 468 times lower than the no-timeline-index condition and about 4.9 times lower than the single-column condition. The absolute saving versus no relevant index is approximately 4.199 ms. These ratios apply only to this selective query and warm-cache workload; the small absolute times must not be marketed as an equivalent end-to-end application speedup.')
#15
page('14 Query Plans and Experimental Limits')
def nodes(plan):
 out=[plan['Node Type'] + ((' on '+plan['Index Name']) if 'Index Name' in plan else '')]
 for ch in plan.get('Plans',[]):out.extend(nodes(ch))
 return out
table(['Condition','Representative plan nodes'],[[k.replace('_',' '),' → '.join(nodes(v['plans'][0]['Plan']))] for k,v in bench['conditions'].items()],[1.8,4.7])
p('The plan evidence explains the observed timings more usefully than a speed ratio alone. Without a relevant timeline index, PostgreSQL must examine a much larger portion of tasks and perform ordering. The single-column index narrows the matching conversation but still leaves the requested order to be satisfied. The composite key aligns the equality predicate with the leading column and the ORDER BY suffix, allowing early termination at the requested limit [5,6]. The stored JSON includes the exact selected nodes, buffer counts and each measured execution time.')
h('14.1 What the experiment does not establish')
p('The measurements are server execution times reported by EXPLAIN ANALYZE. They exclude browser rendering and ordinary API/network latency and include instrumentation overhead. One warmup and a fixed condition order favor a hot, stable cache. Twenty repeated runs on one database are not twenty independent deployments. The workload has uniform conversation sizes and short repeated instruction text; real histories could be skewed and contain larger results or attachments.')
p('The experiment changes only the two relevant task indexes and leaves the rest of the schema intact. It does not measure insert throughput, index-maintenance cost under writes, concurrent readers, cold storage, autovacuum interference or long-term bloat. The composite index adds storage and write work. The results support retaining it for this timeline access pattern, but do not justify adding similar indexes to every foreign key or eliminating the simpler index without examining other queries.')
h('14.2 Follow-up evaluation')
p('A stronger performance study would randomize condition order across repeated database restarts, vary conversation cardinality and row width, include concurrent task inserts, and report latency distributions at both SQL and API boundaries. A workload with one exceptionally large conversation would test whether the first-page benefit persists under skew. Index sizes and write costs should be compared against the saved read time before making a deployment-wide recommendation.')
p('No model API calls are made by this benchmark. Its data are generated and its schema is removed after measurements. This isolation ensures the experiment does not add fake histories to the user’s application or mix synthetic costs with the live demonstration ledger.')
#16
page('15 Discussion and Conclusions')
h('15.1 Database principles demonstrated')
p('The central contribution is a relational account of entitlement and execution. Primary and alternate keys define identity; foreign keys connect an enrollment to accepted work; CHECK constraints distinguish valid and invalid accounting states; row locks serialize conflicting transitions; and queries expose a history that can be independently recomputed. The index experiment connects a specific physical access path to an observed execution plan. Together these examples show how database design shapes application behavior, rather than merely storing a chat transcript.')
p('Several tradeoffs are explicit. Historical snapshots sacrifice some duplication to preserve what was agreed or calculated at an earlier time. Nullable unresolved costs sacrifice a superficially complete total to preserve uncertainty. Short transactions avoid holding locks across network requests but require recovery states for ambiguous external outcomes. Task-level budgets control subsequent dispatch without pretending that an unknown future response cost can be capped after the fact.')
h('15.2 Remaining limitations')
table(['Limitation','Consequence and appropriate next step'],[
['Application-enforced historical immutability','Privileged direct SQL can change past price rows; add restricted roles or append-only enforcement before production billing.'],['Conversation-owner redundancy','Separate FKs do not enforce a matching owner; add a composite ownership constraint after auditing legacy rows.'],['Single-process recovery','Multiple workers need durable ownership, leases and a dispatch protocol.'],['Demonstration subscriptions','No payment, invoice, refund, automatic renewal or quota ledger is implemented.'],['Narrow live evidence','One document task cannot estimate model accuracy, robustness or the value of extra roles.'],['Material retention and deployment','OCR, retention/deletion policy, public HTTPS deployment and broader security testing remain future work.']],[2.0,4.5])
h('15.3 Conclusion')
p('Agent Desk realizes the selected subscription and task-billing topic in a functioning 13-table system. Forty database-backed regression cases pass; a live PDF/TXT workflow produces traceable roles, tools and seven independently verified usage records; deterministic business queries distinguish unresolved amounts from known zero; and a controlled workload supports the composite timeline index. The report’s strongest conclusion is therefore about tested integrity and explainable history. Production financial settlement, distributed reliability and general model quality remain separate engineering and evaluation problems.')
#17
page('References and Reproducibility')
refs=[
'[1] MDS5120. Group Project Requirements. Course handout, three pages. Sections on project stages, timeline and marking criteria. Local source: xid-12430056_1.pdf.',
'[2] Group G14. Agent Desk source repository and tested working-tree snapshot. https://github.com/icey1287/agent-ledger. Base commit 0d66e63112df90c2fc48ed0453b80910968b8cf0; local subscription additions included in the accompanying source archive. Inspected 28 November 2026.',
'[3] PostgreSQL Global Development Group. PostgreSQL 17 Documentation, Constraints. https://www.postgresql.org/docs/17/ddl-constraints.html. Accessed 28 November 2026.',
'[4] PostgreSQL Global Development Group. PostgreSQL 17 Documentation, Explicit Locking. https://www.postgresql.org/docs/17/explicit-locking.html. Accessed 28 November 2026.',
'[5] PostgreSQL Global Development Group. PostgreSQL 17 Documentation, Using EXPLAIN. https://www.postgresql.org/docs/17/using-explain.html. Accessed 28 November 2026.',
'[6] PostgreSQL Global Development Group. PostgreSQL 17 Documentation, Multicolumn Indexes. https://www.postgresql.org/docs/17/indexes-multicolumn.html. Accessed 28 November 2026.'
]
for x in refs:p(x)
h('Reproducing the evidence')
p('Use the accompanying source snapshot, Python dependencies locked in backend/uv.lock and frontend dependencies locked in pnpm-lock.yaml. The evaluated backend used Python 3.13.18. Configure a separate PostgreSQL 17 test database and provide its connection through TEST_DATABASE_URL, then run python -m pytest -q from backend. A missing test connection causes skips and is not a passing database verification. Run pnpm build from frontend to repeat type checking and the production build.')
p('The evidence scripts contain no credentials. collect_evidence.py reads local PostgreSQL credentials from the repository .env and expects the local databases and port described in DEVELOPMENT.md and environment.json; adapt those connection settings for another machine. It creates and removes only its own randomly named schemas in the test database. Its live extraction is read-only and expects the demonstration task already to exist. verify_live.py recalculates captured costs and checks read identifiers; schema_evidence.py exports the physical column dictionary and source hashes.')
p('Reproducing the real model workflow requires an independently configured provider account and may incur provider charges. The source archive deliberately excludes local credentials, session data, database backups and user uploads. Repeating the same prompt can produce a different call sequence and token count. Reproduction of the accounting assertion uses the captured raw usage, not an expectation that a new model run returns identical prose.')
p('The report and evidence reflect the tested local version on 28 November 2026. The source archive is needed alongside the base commit because subscription changes were present in the working tree. Neither this report nor its creation implies that those changes have been pushed or that the report has been submitted to the course.')
# appendix automatically several pages
page('Appendix A Physical Data Dictionary')
p('Extracted from information_schema.columns after executing the current db/schema.sql in an isolated schema. Every table also has id as its primary key and created_at as a non-null timestamp with time zone. N means NOT NULL; Y means NULL is permitted. Keys and cross-column constraints are summarized in Sections 3–4. SQL defaults and ORM client-side defaults are not interchangeable.')
dictionary=json.loads((E/'data-dictionary.json').read_text())
order=['users','sessions','models','model_prices','plans','subscriptions','conversations','tasks','materials','task_tool_grants','agent_runs','model_calls','tool_calls']
for name in order:
 h(name)
 rows=[]
 for col in dictionary:
  if col['table_name']!=name or col['column_name'] in ['id','created_at']:continue
  typ=col['data_type'].replace('character varying','varchar').replace('timestamp with time zone','timestamptz')
  if typ=='varchar':typ+=f"({col['character_maximum_length']})"
  if typ=='numeric':typ+=f"({col['numeric_precision']},{col['numeric_scale']})"
  default=col['column_default'] or '—'
  default=default.replace('::character varying','').replace('::text','').replace('::numeric','')
  if '新对话' in default:default="U&'\\65B0\\5BF9\\8BDD'"
  rows.append([col['column_name'],typ,'Y' if col['is_nullable']=='YES' else 'N',default])
 table(['Column','SQL type','Null','SQL default'],rows,[2.0,1.7,.5,2.3])
page('Appendix B Evidence Manifest')
p('The following artifacts form the audit trail for the reported results. Hashes identify exact bytes; they do not by themselves establish correctness. The accompanying bundle contains the full SHA-256 manifest and the scripts used to collect and check these files. Times in raw captures retain their timezone offsets; reported demonstration times use Asia/Shanghai.')
files=[('tests.xml','All 40 executed cases and individual durations'),('tests.txt','Test summary and deprecation warning'),('frontend-build.txt','Type-check and production-build result'),('live-demo.json','Task, three roles, seven calls, six tool events and two materials'),('live-independent-check.json','Exact arithmetic and material-read verification'),('live-subscription-query.json','Entitlement-to-usage SQL result'),('business-results.json','Deterministic accounting query outputs'),('index-benchmark.json','Sixty measured plans, timings and identical row hashes'),('data-dictionary.json','Physical column metadata'),('environment.json','Hardware, Python, base commit and working-tree status'),('source-sha256.json','Per-file hashes for the tested source snapshot')]
table(['Artifact','Evidence supplied'],files,[2.4,4.1])
h('Selected SHA256 fingerprints')
for name in ['live-demo.json','index-benchmark.json','source-sha256.json']:
 p(name);code(hashlib.sha256((E/name).read_bytes()).hexdigest())
p('The report’s numerical claims derive from the stored measurements rather than the browser display alone. The browser result capture is retained as visual workflow evidence; the JSON and SQL files remain the authoritative sources for exact counts, amounts and query plans. Private user histories and authentication material are not included.')
doc.save(O/'MDS5120_G14_Final_Report.docx')
print('Saved report',len(doc.paragraphs),'paragraphs')
