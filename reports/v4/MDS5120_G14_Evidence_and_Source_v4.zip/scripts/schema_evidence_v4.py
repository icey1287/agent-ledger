from pathlib import Path
import sys,json,uuid
repo=Path.cwd();sys.path.insert(0,str(repo/'backend'))
from dotenv import dotenv_values
from sqlalchemy import create_engine,inspect
from sqlalchemy.engine import URL
v=dotenv_values(repo/'.env'); e=create_engine(URL.create('postgresql+psycopg',username=v['POSTGRES_USER'],password=v['POSTGRES_PASSWORD'],host='127.0.0.1',port=55432,database='agent_ledger_test'))
schema='report_'+uuid.uuid4().hex
with e.begin() as c:
 c.exec_driver_sql(f'CREATE SCHEMA "{schema}"')
try:
 with e.begin() as c:
  c.exec_driver_sql(f'SET LOCAL search_path TO "{schema}"');c.exec_driver_sql((repo/'db/schema.sql').read_text(),execution_options={'no_parameters':True})
  rows=c.exec_driver_sql("SELECT table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,is_nullable,column_default FROM information_schema.columns WHERE table_schema=%s ORDER BY table_name,ordinal_position",(schema,)).mappings().all()
  i=inspect(c); fks={t:i.get_foreign_keys(t,schema=schema) for t in i.get_table_names(schema=schema)}
  out=repo.parent.parent/'outputs/MDS5120-report/evidence'
  (out/'data-dictionary-v4.json').write_text(json.dumps([dict(x) for x in rows],indent=2,default=str))
  (out/'relationships-v4.json').write_text(json.dumps(fks,indent=2,default=str))
  print('Verified tables',len(fks),'FK relationships',sum(map(len,fks.values())),'columns',len(rows))
finally:
 with e.begin() as c:c.exec_driver_sql(f'DROP SCHEMA "{schema}" CASCADE')
 e.dispose()
