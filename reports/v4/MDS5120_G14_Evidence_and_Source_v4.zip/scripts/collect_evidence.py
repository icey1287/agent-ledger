from pathlib import Path
from dotenv import dotenv_values
import psycopg, json, uuid, time, statistics, subprocess, os, hashlib, platform
from psycopg.rows import dict_row
ROOT=Path(__file__).resolve().parents[3]; REPO=ROOT/'work/agent-ledger'; OUT=Path(__file__).resolve().parents[1]; E=OUT/'evidence'
v=dotenv_values(REPO/'.env')
def connect(db):
 return psycopg.connect(host='127.0.0.1',port=55432,user=v['POSTGRES_USER'],password=v['POSTGRES_PASSWORD'],dbname=db,autocommit=True,row_factory=dict_row)
def save(n,x): (E/n).write_text(json.dumps(x,indent=2,default=str))
with connect('agent_platform') as c:
 t=c.execute("select id,created_at,finished_at,status,budget,result,price_id,subscription_id from tasks where instruction like 'Report evidence demo:%' order by created_at desc limit 1").fetchone()
 if t:
  runs=c.execute('select id,parent_id,role,status,output,created_at,finished_at from agent_runs where task_id=%s order by created_at',(t['id'],)).fetchall()
  calls=c.execute('select c.id,r.role,c.status,c.usage_status,c.input_tokens,c.output_tokens,c.cached_tokens,c.cost,c.raw_usage,c.created_at,c.finished_at from model_calls c join agent_runs r on r.id=c.run_id where r.task_id=%s order by c.created_at',(t['id'],)).fetchall()
  tools=c.execute('select tc.tool,tc.arguments,tc.status,tc.output,tc.grant_id from tool_calls tc join agent_runs r on r.id=tc.run_id where r.task_id=%s order by tc.created_at',(t['id'],)).fetchall()
  mats=c.execute('select id,name,kind,length(content) characters,content from materials where task_id=%s',(t['id'],)).fetchall()
  price=c.execute('select version,currency,input_rate,output_rate,cached_rate from model_prices where id=%s',(t['price_id'],)).fetchone()
  save('live-demo.json',dict(task=t,runs=runs,calls=calls,tools=tools,materials=mats,price=price))
  print('Live demo:',t['status'],len(calls),'calls',len(tools),'tools')
if os.environ.get('LIVE_ONLY'): raise SystemExit()
with connect('agent_ledger_test') as c:
 schema='report_'+uuid.uuid4().hex
 c.execute(f'CREATE SCHEMA {schema}'); c.execute(f'SET search_path TO {schema}')
 try:
  c.execute((REPO/'db/schema.sql').read_text()); c.execute((REPO/'db/sample-data.sql').read_text())
  queries={
   'task_totals':"SELECT t.id,t.status,t.budget,COALESCE(sum(c.cost),0) known_cost,count(c.id) FILTER (WHERE c.usage_status='unknown') unknown_calls FROM tasks t LEFT JOIN agent_runs r ON r.task_id=t.id LEFT JOIN model_calls c ON c.run_id=r.id GROUP BY t.id ORDER BY t.id",
   'cost_recalculation':"SELECT c.id,c.cost,((c.input_tokens-c.cached_tokens)*p.input_rate+c.cached_tokens*p.cached_rate+c.output_tokens*p.output_rate)/1000000 recalculated FROM model_calls c JOIN agent_runs r ON r.id=c.run_id JOIN tasks t ON t.id=r.task_id JOIN model_prices p ON p.id=t.price_id ORDER BY c.id",
   'price_versions':"SELECT t.id,t.price_id,p.version FROM tasks t JOIN model_prices p ON p.id=t.price_id ORDER BY t.id",
   'tool_outcomes':"SELECT status,count(*) count FROM tool_calls GROUP BY status ORDER BY status"}
  (E/'business-evidence.sql').write_text('\n\n'.join('-- '+n+'\n'+q+';' for n,q in queries.items()))
  save('business-results.json',{n:c.execute(q).fetchall() for n,q in queries.items()})
  # Controlled deterministic workload in the exact production DDL, isolated from user data.
  c.execute("INSERT INTO conversations(id,user_id,title) SELECT 'bench-c-'||g,'u-alice','Benchmark' FROM generate_series(1,1000) g")
  c.execute("INSERT INTO tasks(id,conversation_id,user_id,price_id,title,instruction,budget,created_at,status) SELECT 'bench-t-'||g,'bench-c-'||((g-1)%1000+1),'u-alice','p-minimax-v1','Benchmark','Deterministic generated workload',1,'2026-01-01'::timestamptz+g*interval '1 second','completed' FROM generate_series(1,200000) g")
  c.execute('VACUUM ANALYZE tasks')
  q="SELECT id,created_at FROM tasks WHERE conversation_id='bench-c-501' ORDER BY created_at,id LIMIT 50"
  (E/'benchmark-query.sql').write_text(q+';\n')
  res={'postgres':c.execute('select version() version').fetchone()['version'],'platform':platform.platform(),'rows':200004,'benchmark_rows':200000,'conversations':1000,'rows_per_conversation':200,'query':q,'protocol':'One warmup and 20 measured EXPLAIN ANALYZE runs per condition. Fixed order. Warm cache. Single connection. No forced planner settings.','conditions':{}}
  for name,ddl in [('no_timeline_index',None),('single_column','CREATE INDEX ix_tasks_conversation_id ON tasks(conversation_id)'),('composite','CREATE INDEX ix_tasks_conv_created ON tasks(conversation_id,created_at,id)')]:
   c.execute('DROP INDEX IF EXISTS ix_tasks_conversation_id'); c.execute('DROP INDEX IF EXISTS ix_tasks_conv_created')
   start=time.perf_counter()
   if ddl:c.execute(ddl)
   build=(time.perf_counter()-start)*1000
   c.execute('ANALYZE tasks')
   c.execute('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+q).fetchone()
   plans=[next(iter(c.execute('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+q).fetchone().values()))[0] for _ in range(20)]
   times=[p['Execution Time'] for p in plans]
   rows=c.execute(q).fetchall()
   res['conditions'][name]={'median_ms':statistics.median(times),'min_ms':min(times),'max_ms':max(times),'execution_ms':times,'index_build_ms':build,'row_count':len(rows),'result_sha256':hashlib.sha256(json.dumps(rows,default=str,sort_keys=True).encode()).hexdigest(),'plans':plans}
  save('index-benchmark.json',res)
  print('Benchmark medians:',{k:z['median_ms'] for k,z in res['conditions'].items()})
 finally: c.execute('SET search_path TO public'); c.execute(f'DROP SCHEMA {schema} CASCADE')
env=os.environ.copy();env['TEST_DATABASE_URL']=f"postgresql+psycopg://{v['POSTGRES_USER']}:{v['POSTGRES_PASSWORD']}@127.0.0.1:55432/agent_ledger_test"
p=subprocess.run(['.venv/bin/python','-m','pytest','-q','--tb=short',f'--junitxml={E}/tests.xml'],cwd=REPO/'backend',env=env,capture_output=True,text=True)
(E/'tests.txt').write_text(p.stdout+p.stderr);print(p.stdout[-1500:]);assert p.returncode==0
save('environment.json',{'python':subprocess.check_output([str(REPO/'backend/.venv/bin/python'),'--version'],text=True).strip(),'hardware':subprocess.check_output(['sysctl','-n','machdep.cpu.brand_string'],text=True).strip(),'memory_bytes':subprocess.check_output(['sysctl','-n','hw.memsize'],text=True).strip(),'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'working_tree_status':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True)})
