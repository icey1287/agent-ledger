exec(open(__file__.replace('schema_evidence.py','collect_evidence.py')).read().split("with connect('agent_platform')")[0])
with connect('agent_ledger_test') as c:
 schema='report_dict_'+uuid.uuid4().hex;c.execute(f'CREATE SCHEMA {schema}');c.execute(f'SET search_path TO {schema}')
 try:
  c.execute((REPO/'db/schema.sql').read_text())
  save('data-dictionary.json',c.execute('SELECT table_name,column_name,data_type,character_maximum_length,numeric_precision,numeric_scale,is_nullable,column_default FROM information_schema.columns WHERE table_schema=%s ORDER BY table_name,ordinal_position',(schema,)).fetchall())
 finally:c.execute('SET search_path TO public');c.execute(f'DROP SCHEMA {schema} CASCADE')
import zipfile
paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z'],cwd=REPO).decode().split('\0')
manifest={}
with zipfile.ZipFile(OUT/'AgentDesk-source-snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(set(paths)):
  if not p or p.startswith('.env') and p!='.env.example':continue
  file=REPO/p
  if file.is_file():
   manifest[p]=hashlib.sha256(file.read_bytes()).hexdigest();z.write(file,'agent-ledger/'+p)
save('source-sha256.json',manifest)
