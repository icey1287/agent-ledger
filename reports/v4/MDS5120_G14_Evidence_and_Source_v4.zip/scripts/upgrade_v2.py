from pathlib import Path
P=Path(__file__).parent
s=(P/'build_report.py').read_text()
a=s.index('def diagram():');b=s.index('def chart():')
s=s[:a]+'''def diagram():
 groups=[('er_accounts.png',[
 ('users','sessions','authenticates','1,1','user_id'),
 ('users','conversations','owns','1,1','user_id'),
 ('users','subscriptions','holds','1,1','user_id'),
 ('plans','subscriptions','defines offer','1,1','plan_id'),
 ('users','tasks','requests','1,1','user_id'),
 ('conversations','tasks','contains','0,1','conversation_id'),
 ('models','model_prices','has versions','1,1','model_id'),
 ('model_prices','tasks','prices','1,1','price_id'),
 ('subscriptions','tasks','authorizes','0,1','subscription_id + user_id')]),
 ('er_execution.png',[
 ('tasks','materials','contains','1,1','task_id'),
 ('tasks','task_tool_grants','grants','1,1','task_id'),
 ('tasks','agent_runs','executes','1,1','task_id'),
 ('agent_runs','agent_runs','parents','0,1','parent_id'),
 ('agent_runs','model_calls','invokes','1,1','run_id'),
 ('agent_runs','tool_calls','performs','1,1','run_id'),
 ('task_tool_grants','tool_calls','authorizes read','0,1','grant_id'),
 ('users','model_calls','reconciles','0,1','reconciled_by')])]
 for name,rels in groups:
  im=Image.new('RGB',(1800,1400),'white');d=ImageDraw.Draw(im)
  for i,(left,right,rel,card,fk) in enumerate(rels):
   y=50+i*145
   for x,label in [(15,left),(1320,right)]:
    d.rectangle((x,y,x+460,y+105),fill='#edf2f5',outline='#34495e',width=3)
    d.text((x+230,y+30),label,font=font(31),anchor='mm',fill='#17232c')
    sub='PK id' if x==15 else 'FK '+fk
    d.text((x+230,y+73),sub,font=font(23),anchor='mm',fill='#333333')
   cy=y+52
   d.line((475,cy,705,cy),fill='#34495e',width=3)
   # Double line denotes total participation on mandatory child side.
   if card=='1,1':
    d.line((1095,cy-5,1320,cy-5),fill='#34495e',width=2);d.line((1095,cy+5,1320,cy+5),fill='#34495e',width=2)
   else:d.line((1095,cy,1320,cy),fill='#34495e',width=3)
   d.polygon([(705,cy),(900,y+4),(1095,cy),(900,y+101)],fill='white',outline='#34495e',width=3)
   d.text((900,cy),rel,font=font(26),anchor='mm',fill='#17232c')
   d.text((580,cy-25),'(0,N)',font=font(27),anchor='mm',fill='#333333')
   d.text((1210,cy-25),'('+card+')',font=font(27),anchor='mm',fill='#333333')
  d.text((20,1370),'Min–max participation at each entity end. Double line = mandatory participation.',font=font(28),fill='#333333')
  im.save(F/name)
''' + s[b:]
a=s.index("page('2 Conceptual Data Model')");b=s.index('# 4\n',a)
s=s[:a]+'''page('2 Conceptual Data Model')
h('2.1 Accounts subscriptions and task admission')
p('Figures 1a and 1b form one complete ER model, drawn in Chen-style relationship notation with min–max participation. Rectangles denote entity types; diamonds name relationships. The pair beside an entity states how many relationship instances one occurrence of that entity may join. Thus users (0,N) authenticates sessions (1,1) means that a user may have no sessions or many, while each session must belong to exactly one user. A double line marks total participation. Repeated rectangles refer to the same entity type, not additional tables.')
fig('er_accounts.png','Figure 1a. Account, entitlement and pricing relationships. All thirteen entity types are covered across the two panels. PK identifies a primary key; FK labels the child attributes implementing the relationship.',6.5)
p('The diagram reflects the implemented schema, including legacy optionality. A task can have zero or one conversation and zero or one subscription in stored data; new application-created tasks require both. A subscription always belongs to one user and one plan. The user can have many historical subscriptions, but a partial unique index permits only one stored active subscription at a time. This conditional rule does not change the lifetime (0,N) relationship.')
p('The authorizes relationship is implemented by the composite foreign key (subscription_id, user_id), not by subscription_id alone. It requires the task and enrollment to have the same owner whenever the subscription link is present. Each task must reference exactly one price version, and each version belongs to exactly one model.')
page('2 Conceptual Data Model Continued')
h('2.2 Execution materials and audit relationships')
fig('er_execution.png','Figure 1b. Execution and audit relationships, including the recursive agent-run parent link and the optional reconciliation actor. The two agent_runs boxes in the parents relationship represent parent and child roles of the same entity.',6.5)
p('A material, grant and agent run each require a task. A model call and tool call each require an agent run. A root run has no parent; a child run has one parent. SQL permits multiple children, while application rules restrict delegation to the coordinator and the supported summary/review roles. The self-reference alone does not prohibit cycles or a parent from another task; those are separate application-level invariants.')
p('A tool call may reference no grant because delegation is not a material-read permission. A model call may have no reconciliation actor because ordinary successful calls need no correction. When reconciled_by is present it references one user; administrator status is verified by the application rather than encoded as a separate administrator entity or SQL foreign-key condition.')
p('All 17 foreign-key relationships are represented across the panels. Entity identity and scalar attributes are mapped in Section 3 and Appendix A. Participation constraints describe which entity links must exist; they do not enforce every temporal business rule. For example, a subscription foreign key proves existence and ownership, while the transaction must still verify eligibility at admission time. No unsupported subtype hierarchy is introduced: user/admin and the three agent roles are constrained attributes in the current design.')
''' +s[b:]
a=s.index("page('4 Normalization and Integrity')");b=s.index("p('A blanket claim",a)
s=s[:a]+'''page('4 Normalization and Integrity')
h('4.1 Candidate keys and functional dependencies')
p('For each relation R below, A denotes all of its scalar attributes. A functional dependency X → A means that a value of X identifies one complete row. A candidate key is a minimal such determinant, not simply any set declared UNIQUE. The inventory is derived from the current non-null primary and alternate keys and the intended business semantics. It distinguishes unconditional keys from constraints applying only to a subset of rows.')
table(['Relation','Candidate keys','Key dependencies'],[
 ['users','{id}; {username}','id → A; username → A'],
 ['sessions','{id}; {token_hash}','id → A; token_hash → A'],
 ['models','{id}; {name}','id → A; name → A'],
 ['model_prices','{id}; {model_id, version}','id → A; (model_id, version) → A'],
 ['plans','{id}; {code}','id → A; code → A'],
 ['subscriptions','{id}','id → A'],
 ['conversations','{id}','id → A'],
 ['tasks','{id}','id → A; ownership dependencies discussed below'],
 ['materials','{id}','id → A'],
 ['task_tool_grants','{id}; {task_id, tool}','id → A; (task_id, tool) → A'],
 ['agent_runs','{id}','id → A'],
 ['model_calls','{id}','id → A'],
 ['tool_calls','{id}','id → A']],[1.5,2.2,2.8])
p('UNIQUE(subscription.id, user_id) is a superkey but not a candidate key: id alone already identifies the row. It exists to support the composite owner foreign key. user_id is not a key for the full subscriptions relation because expired and cancelled histories coexist. It is unique only in the stored-active subset. Likewise, provider_request_id is nullable and not declared unique, and neither a file name nor a role name identifies a record.')
p('A surrogate primary key does not eliminate other functional dependencies. Under the intended ownership rule, a non-null conversation_id determines a task owner, and a non-null subscription_id also determines that owner. Neither identifies one task, because each parent can have many tasks. The first dependency is enforced by API validation; the second is enforced by the composite subscription-owner foreign key. These redundancies must be assessed independently of id → A.')
p('The inventory lists identifying dependencies, not an exhaustive formal cover of every possible domain dependency. JSON arguments and provider usage are opaque document-valued attributes at this relational boundary. No claim is made that the nested contents are themselves a normalized relational schema. Queryable accounting fields are extracted into typed scalar columns.')
page('4 Normalization and Integrity Continued')
h('4.2 Decomposition and normal form reasoning')
p('A useful design starting point is a hypothetical task record containing user credentials, a subscription offer, model rates and repeated lists of runs, calls and grants. That structure would repeat independent facts and make both updates and aggregation fragile. The implemented decomposition separates entity identity from repeating events and records only foreign keys between them.')
table(['Stage','Dependency or anomaly','Implemented decomposition'],[
 ['First normal form','A task has a repeating collection of calls, materials and grants.','Create one row per material, run, model call, tool call and grant; use foreign keys instead of numbered columns or embedded billing lists.'],
 ['Second normal form','In a hypothetical Price(model_id, version, model_name, rates), model_id → model_name depends on part of the composite key.','Keep model identity in models; keep version-dependent currency and rates in model_prices.'],
 ['Second normal form','In Grant(task_id, tool, task_budget, expiry), task_id → task_budget depends on only part of the grant key.','Keep budget in tasks and permission attributes in task_tool_grants.'],
 ['Third normal form','If a session stored a username, session_id → user_id → username would repeat a non-key fact.','sessions stores user_id; users stores username and credentials.'],
 ['Third normal form','If each call stored current model rates, call_id → run_id → task_id → price_id would repeat pricing facts across events.','Calls reference runs; runs reference tasks; tasks reference the fixed model_prices row.']],[1.1,2.7,2.7])
p('These decompositions preserve reconstructability: joining a session to its required user, or a price row to its required model, uses a primary-key/foreign-key relationship. For the conceptual two-relation decomposition, the shared parent identifier determines the parent relation, satisfying the usual lossless-join condition. Parent facts remain in one relation, and alternate-key constraints remain enforceable locally. Optional legacy links require outer joins when retaining unlinked records; a natural inner join would intentionally discard those rows.')
p('With the listed key dependencies and no additional non-key dependencies, users, sessions, models, model_prices, plans, conversations, materials, task_tool_grants and agent_runs satisfy BCNF at the modeled scalar level: every nontrivial determinant is a superkey. This is an assumption-bounded assessment, not a proof inferred merely from the presence of an id column. Row-local CHECK conditions restrict valid values but are not automatically functional dependencies or normal-form violations.')
p('The remaining relations need qualifications. subscriptions stores enrollment-time offer snapshots; tasks retains redundant ownership links; model_calls stores derived cost and raw usage; tool_calls stores both an execution reference and an optional authorization reference. Their historical and cross-relation consistency obligations are discussed next. The system is designed around normalized entities and event relations, with explicit exceptions rather than a blanket claim of BCNF for all thirteen tables.')
page('4 Normalization and Integrity Exceptions')
h('4.3 Historical snapshots derived values and ownership')
''' + s[b:]
s=s.replace("p('Subscription plan name, display price and currency are enrollment-time snapshots.","p('Subscription plan name, display price and currency are enrollment-time snapshots.")
# Add precise snapshot semantics without expanding original exceptions page too much.
s=s.replace("They intentionally describe a historical agreement rather than the current plan row.","They describe enrollment-time terms: plan_id does not determine these values across all historical enrollments if the offer changes. A versioned plan relation could factor out repeated historical offers.")
s=s.replace("p('PostgreSQL constraints reject invalid row states independently", "p('A tool call’s run and grant should resolve to the same task, but their separate foreign keys do not establish that equality. Application authorization checks supply this cross-relation rule. Similarly, raw usage and extracted counts may duplicate information for audit purposes; normalization alone cannot validate their agreement. PostgreSQL constraints reject invalid row states independently")
s=s.replace('Figure 2. Unaltered','Figure 2. Unaltered')
s=s.replace("O/'MDS5120_G14_Final_Report.docx'","O/'MDS5120_G14_Final_Report_v2.docx'")
(P/'build_report_v2.py').write_text(s)
