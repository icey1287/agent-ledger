exec(open(__file__.replace('verify_live.py','collect_evidence.py')).read().split("with connect('agent_platform')")[0])
from decimal import Decimal
x=json.loads((E/'live-demo.json').read_text());p=x['price'];total=Decimal(0)
for row in x['calls']:
 amount=((row['input_tokens']-row['cached_tokens'])*Decimal(p['input_rate'])+row['cached_tokens']*Decimal(p['cached_rate'])+row['output_tokens']*Decimal(p['output_rate']))/1000000
 assert amount==Decimal(row['cost']); total+=amount
assert x['task']['status']=='completed' and len(x['materials'])==2
readids={t['arguments']['material_id'] for t in x['tools'] if t['tool']=='read_material' and t['status']=='completed'}
assert readids=={m['id'] for m in x['materials']}
assert {r['role'] for r in x['runs']}=={'coordinator','summary','review'}
with connect('agent_platform') as c:
 q="SELECT s.plan_name,s.display_price,s.currency plan_currency,p.currency usage_currency,count(DISTINCT t.id) tasks,count(c.id) calls,sum(c.cost) known_usage_cost,count(c.id) FILTER(WHERE c.usage_status='unknown') unknown_calls FROM subscriptions s JOIN tasks t ON t.subscription_id=s.id AND t.user_id=s.user_id JOIN model_prices p ON p.id=t.price_id JOIN agent_runs r ON r.task_id=t.id JOIN model_calls c ON c.run_id=r.id WHERE t.id=%s GROUP BY s.id,p.currency"
 save('live-subscription-query.json',c.execute(q,(x['task']['id'],)).fetchall())
 (E/'live-subscription-query.sql').write_text(q.replace('%s',"'"+x['task']['id']+"'")+';')
 totals={k:sum(c[k] for c in x['calls']) for k in ['input_tokens','output_tokens','cached_tokens']}
 save('live-independent-check.json',dict(cost=total,all_seven_costs_match=True,both_materials_read=True,three_roles_completed=True,**totals))
 print(total,totals)
