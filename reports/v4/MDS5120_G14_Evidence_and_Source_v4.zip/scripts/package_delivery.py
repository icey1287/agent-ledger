from pathlib import Path
import json,hashlib,zipfile,shutil
from pypdf import PdfReader
O=Path(__file__).resolve().parents[1];E=O/'evidence'
b=json.loads((E/'index-benchmark.json').read_text());assert len({v['result_sha256'] for v in b['conditions'].values()})==1
assert all(len(v['plans'])==20 for v in b['conditions'].values())
env=json.loads((E/'environment.json').read_text());env.update(postgres=b['postgres'],postgres_host='127.0.0.1',postgres_port=55432,application_database='agent_platform',test_database='agent_ledger_test');(E/'environment.json').write_text(json.dumps(env,indent=2))
with zipfile.ZipFile(O/'AgentDesk-source-snapshot.zip') as z:
 for name,digest in json.loads((E/'source-sha256.json').read_text()).items():assert hashlib.sha256(z.read('agent-ledger/'+name)).hexdigest()==digest
shutil.copy2(O/'verified/MDS5120_G14_Final_Report.pdf',O/'MDS5120_G14_Final_Report.pdf')
r=PdfReader(O/'MDS5120_G14_Final_Report.pdf');assert len(r.pages)==22
text='\n'.join(p.extract_text() for p in r.pages)
for required in ['G14','226040366','226040350','226040345','226040349','226040416','226040336','0.0068438','4.208','0.009','Appendix B']:
 assert required in text,required
(O/'README.txt').write_text('MDS5120 Group G14 report delivery - 28 November 2026\n\nReport: PDF and editable Word contain the same 22-page report.\nMembers: Changze Li, Peng Si, Haodong He, Yiming Zhang, Qijie Weng, Zhikang An.\n\nEvidence classes\n1. 40 PostgreSQL-backed automated cases with mocked provider transport.\n2. Real DeepSeek PDF/TXT demonstration: 7 model calls; all costs independently checked.\n3. Deterministic business SQL fixtures.\n4. 200,000 generated tasks, three index conditions, 20 measured plans per condition.\n\nEvidence/ contains raw JSON, SQL, test XML and logs; figures/ contains the report figures and browser captures. scripts/ contains the report generator and evidence collectors.\nAgentDesk-source-snapshot.zip contains the tested source, including local subscription changes after base commit 0d66e63112df90c2fc48ed0453b80910968b8cf0. It does not contain .env, database backups, account sessions or private user uploads. source-sha256.json verifies every archived source file.\n\nFor offline review, inspect live-demo.json and live-independent-check.json; verify individual costs from raw usage and rates. The SQL measurement JSON contains all sixty execution plans and the returned-row hash for each condition.\n\nFor reruns, unpack the source to work/agent-ledger next to an outputs/MDS5120-report layout, install the locked backend/frontend dependencies, and configure your own disposable PostgreSQL database. The collector uses a repository .env and local port 55432; adapt its connection settings to your environment. The tests can instead receive TEST_DATABASE_URL directly. Each collector creates and drops only its own temporary schema. Do not use a production database for tests.\n\nThe live extract expects the existing demonstration task. A fresh live run requires your own provider credential and may incur charges. The model output and usage are not expected to be identical on a fresh run. Ledger amounts are local demonstration rates, not supplier invoices.\n\nNo course submission or GitHub push was performed as part of this report delivery.\n')
files=[p for folder in ['evidence','figures','scripts'] for p in (O/folder).rglob('*') if p.is_file() and '__pycache__' not in str(p)]+[O/'README.txt',O/'AgentDesk-source-snapshot.zip']
manifest={str(p.relative_to(O)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files};(O/'SHA256SUMS.json').write_text(json.dumps(manifest,indent=2))
with zipfile.ZipFile(O/'MDS5120_G14_Evidence_and_Source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in files+[O/'SHA256SUMS.json']:z.write(p,p.relative_to(O))
print('Verified: 22 pages, six IDs, 60 plans, identical query results and complete source manifest.')
print('PDF, Word and evidence package created.')
