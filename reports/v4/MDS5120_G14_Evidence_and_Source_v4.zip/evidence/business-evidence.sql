-- task_totals
SELECT t.id,t.status,t.budget,COALESCE(sum(c.cost),0) known_cost,count(c.id) FILTER (WHERE c.usage_status='unknown') unknown_calls FROM tasks t LEFT JOIN agent_runs r ON r.task_id=t.id LEFT JOIN model_calls c ON c.run_id=r.id GROUP BY t.id ORDER BY t.id;

-- cost_recalculation
SELECT c.id,c.cost,((c.input_tokens-c.cached_tokens)*p.input_rate+c.cached_tokens*p.cached_rate+c.output_tokens*p.output_rate)/1000000 recalculated FROM model_calls c JOIN agent_runs r ON r.id=c.run_id JOIN tasks t ON t.id=r.task_id JOIN model_prices p ON p.id=t.price_id ORDER BY c.id;

-- price_versions
SELECT t.id,t.price_id,p.version FROM tasks t JOIN model_prices p ON p.id=t.price_id ORDER BY t.id;

-- tool_outcomes
SELECT status,count(*) count FROM tool_calls GROUP BY status ORDER BY status;